CoreBlog
========

Proyecto de la asignatura CORE 2013-2014.

